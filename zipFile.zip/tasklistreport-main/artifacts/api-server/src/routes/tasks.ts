import { Router } from "express";
import { db, taskListsTable, tasksTable, userSettingsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { requireAuth, getUserId } from "../lib/auth";
import { sendDailyReport } from "../lib/email";
import { ensureTodayList, getLocalDateString } from "../lib/carryover";
import { triggerShipmentForCompletedPrint } from "../lib/inbox";

const router = Router();

const MAX_TASKS = 100;
const MAX_TASK_LENGTH = 500;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

function isValidDate(date: string): boolean {
  if (!DATE_REGEX.test(date)) return false;
  const d = new Date(date);
  return !isNaN(d.getTime());
}

router.get("/tasks/today", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();

  await ensureTodayList(userId, today);

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.json({ id: 0, date: today, submitted: false, submittedAt: null, tasks: [] });
    return;
  }

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.taskListId, taskList.id))
    .orderBy(tasksTable.position);

  res.json({
    id: taskList.id,
    date: taskList.date,
    submitted: taskList.submitted,
    submittedAt: taskList.submittedAt?.toISOString() ?? null,
    tasks: tasks.map((t) => ({
      id: t.id,
      text: t.text,
      completed: t.completed,
      note: t.note,
      position: t.position,
      createdAt: t.createdAt.toISOString(),
    })),
  });
});

router.post("/tasks/today", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();
  const { rawText } = req.body as { rawText?: unknown };

  if (typeof rawText !== "string") {
    res.status(400).json({ error: "rawText must be a string." });
    return;
  }

  if (rawText.length > MAX_TASKS * MAX_TASK_LENGTH) {
    res.status(400).json({ error: "Input too large." });
    return;
  }

  const lines = rawText
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, MAX_TASKS);

  const invalidLine = lines.find((l) => l.length > MAX_TASK_LENGTH);
  if (invalidLine) {
    res.status(400).json({ error: `Each task must be ${MAX_TASK_LENGTH} characters or fewer.` });
    return;
  }

  const existing = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  let taskListId: number;

  if (existing.length > 0) {
    taskListId = existing[0].id;
    await db.delete(tasksTable).where(eq(tasksTable.taskListId, taskListId));
  } else {
    const [newList] = await db
      .insert(taskListsTable)
      .values({ userId, date: today, submitted: false })
      .returning();
    taskListId = newList.id;
  }

  if (lines.length > 0) {
    await db.insert(tasksTable).values(
      lines.map((text, i) => ({ taskListId, text, completed: false, position: i }))
    );
  }

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(eq(taskListsTable.id, taskListId))
    .limit(1);

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.taskListId, taskListId))
    .orderBy(tasksTable.position);

  res.json({
    id: taskList.id,
    date: taskList.date,
    submitted: taskList.submitted,
    submittedAt: taskList.submittedAt?.toISOString() ?? null,
    tasks: tasks.map((t) => ({ id: t.id, text: t.text, completed: t.completed, note: t.note, position: t.position, createdAt: t.createdAt.toISOString() })),
  });
});

router.post("/tasks/today/add", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();
  const { rawText } = req.body as { rawText?: unknown };

  if (typeof rawText !== "string") {
    res.status(400).json({ error: "rawText must be a string." });
    return;
  }

  const lines = rawText
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, MAX_TASKS);

  const invalidLine = lines.find((l) => l.length > MAX_TASK_LENGTH);
  if (invalidLine) {
    res.status(400).json({ error: `Each task must be ${MAX_TASK_LENGTH} characters or fewer.` });
    return;
  }

  let [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  let taskListId: number;

  if (!taskList) {
    const [newList] = await db
      .insert(taskListsTable)
      .values({ userId, date: today, submitted: false })
      .returning();
    taskList = newList;
    taskListId = newList.id;
  } else {
    taskListId = taskList.id;
  }

  if (lines.length > 0) {
    const existing = await db
      .select()
      .from(tasksTable)
      .where(eq(tasksTable.taskListId, taskListId));
    const nextPosition = existing.length;

    await db.insert(tasksTable).values(
      lines.map((text, i) => ({ taskListId, text, completed: false, position: nextPosition + i }))
    );
  }

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.taskListId, taskListId))
    .orderBy(tasksTable.position);

  res.json({
    id: taskList.id,
    date: taskList.date,
    submitted: taskList.submitted,
    submittedAt: taskList.submittedAt?.toISOString() ?? null,
    tasks: tasks.map((t) => ({ id: t.id, text: t.text, completed: t.completed, note: t.note, position: t.position, createdAt: t.createdAt.toISOString() })),
  });
});

router.delete("/tasks/today/delete", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();
  const { taskId } = req.body as { taskId?: unknown };

  if (typeof taskId !== "number" || !Number.isInteger(taskId) || taskId <= 0) {
    res.status(400).json({ error: "Invalid taskId." });
    return;
  }

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.status(404).json({ error: "No task list for today." });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(and(eq(tasksTable.id, taskId), eq(tasksTable.taskListId, taskList.id)))
    .limit(1);

  if (!task) {
    res.status(404).json({ error: "Task not found." });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.id, taskId));

  res.json({ success: true, message: "Task removed." });
});

router.delete("/tasks/today/reset", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.json({ success: true, message: "Nothing to reset." });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.taskListId, taskList.id));
  await db.delete(taskListsTable).where(eq(taskListsTable.id, taskList.id));

  res.json({ success: true, message: "Day reset successfully." });
});

router.patch("/tasks/today/toggle", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const { taskId } = req.body as { taskId?: unknown };
  const today = getLocalDateString();

  if (typeof taskId !== "number" || !Number.isInteger(taskId) || taskId <= 0) {
    res.status(400).json({ error: "Invalid taskId." });
    return;
  }

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.status(404).json({ error: "No task list for today." });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(and(eq(tasksTable.id, taskId), eq(tasksTable.taskListId, taskList.id)))
    .limit(1);

  if (!task) {
    res.status(404).json({ error: "Task not found." });
    return;
  }

  const [updated] = await db
    .update(tasksTable)
    .set({ completed: !task.completed })
    .where(eq(tasksTable.id, taskId))
    .returning();

  // If a Print task was just marked complete, trigger its Shipment follow-up.
  if (updated.completed && !task.completed) {
    try {
      await triggerShipmentForCompletedPrint(updated.text);
    } catch {
      // Logged inside the helper; never block the toggle response.
    }
  }

  res.json({
    id: updated.id,
    text: updated.text,
    completed: updated.completed,
    note: updated.note,
    position: updated.position,
    createdAt: updated.createdAt.toISOString(),
  });
});

router.patch("/tasks/today/note", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const { taskId, note } = req.body as { taskId?: unknown; note?: unknown };
  const today = getLocalDateString();

  if (typeof taskId !== "number" || !Number.isInteger(taskId) || taskId <= 0) {
    res.status(400).json({ error: "Invalid taskId." });
    return;
  }

  if (typeof note !== "string") {
    res.status(400).json({ error: "note must be a string." });
    return;
  }

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.status(404).json({ error: "No task list for today." });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(and(eq(tasksTable.id, taskId), eq(tasksTable.taskListId, taskList.id)))
    .limit(1);

  if (!task) {
    res.status(404).json({ error: "Task not found." });
    return;
  }

  const [updated] = await db
    .update(tasksTable)
    .set({ note })
    .where(eq(tasksTable.id, taskId))
    .returning();

  res.json({
    id: updated.id,
    text: updated.text,
    completed: updated.completed,
    note: updated.note,
    position: updated.position,
    createdAt: updated.createdAt.toISOString(),
  });
});

router.post("/tasks/today/submit", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, today)))
    .limit(1);

  if (!taskList) {
    res.status(404).json({ error: "No task list for today." });
    return;
  }

  if (taskList.submitted) {
    res.json({ success: true, message: "Already submitted." });
    return;
  }

  await db
    .update(taskListsTable)
    .set({ submitted: true, submittedAt: new Date() })
    .where(eq(taskListsTable.id, taskList.id));

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.taskListId, taskList.id))
    .orderBy(tasksTable.position);

  const [settings] = await db
    .select()
    .from(userSettingsTable)
    .where(eq(userSettingsTable.userId, userId))
    .limit(1);

  const recipientEmails = settings?.recipientEmails ?? "";

  const emailResult = await sendDailyReport(
    recipientEmails,
    today,
    tasks.map((t) => ({ text: t.text, completed: t.completed, note: t.note ?? "" })),
    userId
  );

  res.json(emailResult);
});

router.get("/tasks/history", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const today = getLocalDateString();

  const taskLists = await db
    .select()
    .from(taskListsTable)
    .where(eq(taskListsTable.userId, userId))
    .orderBy(desc(taskListsTable.date));

  const pastLists = taskLists.filter((tl) => tl.date !== today);

  const entries = await Promise.all(
    pastLists.map(async (tl) => {
      const tasks = await db
        .select()
        .from(tasksTable)
        .where(eq(tasksTable.taskListId, tl.id));
      return {
        id: tl.id,
        date: tl.date,
        submitted: tl.submitted,
        completedCount: tasks.filter((t) => t.completed).length,
        totalCount: tasks.length,
      };
    })
  );

  res.json({ entries });
});

router.get("/tasks/history/:date", requireAuth, async (req, res) => {
  const userId = getUserId(req);
  const { date } = req.params;

  if (!isValidDate(date)) {
    res.status(400).json({ error: "Invalid date format." });
    return;
  }

  const [taskList] = await db
    .select()
    .from(taskListsTable)
    .where(and(eq(taskListsTable.userId, userId), eq(taskListsTable.date, date)))
    .limit(1);

  if (!taskList) {
    res.status(404).json({ error: "No task list found for this date." });
    return;
  }

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.taskListId, taskList.id))
    .orderBy(tasksTable.position);

  res.json({
    id: taskList.id,
    date: taskList.date,
    submitted: taskList.submitted,
    submittedAt: taskList.submittedAt?.toISOString() ?? null,
    tasks: tasks.map((t) => ({ id: t.id, text: t.text, completed: t.completed, note: t.note, position: t.position, createdAt: t.createdAt.toISOString() })),
  });
});

export default router;
