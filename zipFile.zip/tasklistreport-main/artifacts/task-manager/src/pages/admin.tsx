import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useIsAdmin } from "@/hooks/use-admin";
import { Redirect } from "wouter";
import { Shield, ChevronRight, Users, CheckCircle2, Circle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type UserEntry = {
  userId: string;
  displayName: string;
  dates: { id: number; date: string; submitted: boolean; completedCount: number; totalCount: number }[];
};

type TaskItem = { id: number; text: string; completed: boolean; position: number };
type TaskDetail = { id: number; date: string; submitted: boolean; submittedAt: string | null; userId: string; tasks: TaskItem[] };

async function fetchAdminUsers(): Promise<{ users: UserEntry[] }> {
  const res = await fetch("/api/admin/users", { credentials: "include" });
  if (!res.ok) throw new Error("Failed to fetch");
  return res.json();
}

async function fetchUserDateTasks(userId: string, date: string): Promise<TaskDetail> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/tasks/${date}`, { credentials: "include" });
  if (!res.ok) throw new Error("Failed to fetch");
  return res.json();
}

function TaskDetailPanel({ userId, date, onBack }: { userId: string; date: string; onBack: () => void }) {
  const { data, isLoading } = useQuery({
    queryKey: ["admin-tasks", userId, date],
    queryFn: () => fetchUserDateTasks(userId, date),
  });

  if (isLoading) return <div className="text-muted-foreground text-sm py-8 text-center">Loading...</div>;
  if (!data) return null;

  const completed = data.tasks.filter((t) => t.completed).length;
  const total = data.tasks.length;

  return (
    <div>
      <Button variant="ghost" size="sm" className="mb-4 text-muted-foreground gap-2" onClick={onBack}>
        &larr; Back to users
      </Button>
      <div className="mb-6">
        <h2 className="text-xl font-serif font-semibold">{date}</h2>
        <div className="flex items-center gap-3 mt-1">
          <span className="text-sm text-muted-foreground">{completed}/{total} tasks completed</span>
          {data.submitted && <Badge variant="secondary" className="text-xs">Submitted</Badge>}
        </div>
      </div>
      <div className="space-y-2">
        {data.tasks.map((task) => (
          <div
            key={task.id}
            className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card"
          >
            {task.completed
              ? <CheckCircle2 size={18} className="text-primary shrink-0" />
              : <Circle size={18} className="text-muted-foreground shrink-0" />
            }
            <span className={task.completed ? "line-through text-muted-foreground" : "text-foreground"}>
              {task.text}
            </span>
          </div>
        ))}
        {data.tasks.length === 0 && (
          <p className="text-muted-foreground text-sm py-4 text-center">No tasks for this day.</p>
        )}
      </div>
    </div>
  );
}

export default function AdminPanel() {
  const isAdmin = useIsAdmin();
  const [selected, setSelected] = useState<{ userId: string; date: string } | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: fetchAdminUsers,
    enabled: isAdmin,
  });

  if (!isAdmin) return <Redirect to="/app" />;

  return (
    <div>
      <div className="flex items-center gap-3 mb-8">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
          <Shield size={18} className="text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-serif font-semibold">Admin Panel</h1>
          <p className="text-sm text-muted-foreground mt-0.5">View all users and their daily task submissions</p>
        </div>
      </div>

      {selected ? (
        <TaskDetailPanel
          userId={selected.userId}
          date={selected.date}
          onBack={() => setSelected(null)}
        />
      ) : (
        <>
          {isLoading && <p className="text-muted-foreground text-sm">Loading...</p>}

          {data?.users.length === 0 && (
            <div className="text-center py-16 text-muted-foreground">
              <Users size={32} className="mx-auto mb-3 opacity-30" />
              <p>No user data yet.</p>
            </div>
          )}

          <div className="space-y-6">
            {data?.users.map((user) => (
              <Card key={user.userId} className="overflow-hidden">
                <CardHeader className="pb-3 bg-muted/30">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Users size={16} className="text-muted-foreground" />
                    {user.displayName}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-border">
                    {user.dates.map((entry) => (
                      <button
                        key={entry.id}
                        onClick={() => setSelected({ userId: user.userId, date: entry.date })}
                        className="w-full flex items-center justify-between px-5 py-3 hover:bg-muted/40 transition-colors text-left"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-medium">{entry.date}</span>
                          {entry.submitted && (
                            <Badge variant="secondary" className="text-xs">Submitted</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm text-muted-foreground">
                            {entry.completedCount}/{entry.totalCount} done
                          </span>
                          <div className="w-20 h-1.5 rounded-full bg-muted overflow-hidden">
                            <div
                              className="h-full bg-primary rounded-full transition-all"
                              style={{ width: entry.totalCount ? `${(entry.completedCount / entry.totalCount) * 100}%` : "0%" }}
                            />
                          </div>
                          <ChevronRight size={14} className="text-muted-foreground" />
                        </div>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
