import { Link } from "wouter";
import { useGetTaskHistory, getGetTaskHistoryQueryKey } from "@workspace/api-client-react";
import { format, parseISO } from "date-fns";
import { Loader2, ChevronRight, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function HistoryList() {
  const { data: historyList, isLoading } = useGetTaskHistory({
    query: {
      queryKey: getGetTaskHistoryQueryKey()
    }
  });

  if (isLoading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const entries = historyList?.entries || [];

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-serif tracking-tight mb-2">History</h1>
        <p className="text-muted-foreground">Past days and accomplishments.</p>
      </div>

      {entries.length === 0 ? (
        <div className="text-center py-16 px-4 border border-dashed rounded-xl bg-card/30">
          <p className="text-muted-foreground text-lg">No past days recorded yet.</p>
          <p className="text-sm text-muted-foreground mt-2">Submit your first day from the Today view.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {entries.map((entry) => {
            const dateObj = parseISO(entry.date);
            const formattedDate = format(dateObj, "EEEE, MMMM d, yyyy");
            const progress = entry.totalCount > 0 ? (entry.completedCount / entry.totalCount) * 100 : 0;
            const allCompleted = entry.totalCount > 0 && entry.completedCount === entry.totalCount;

            return (
              <Link key={entry.id} href={`/history/${entry.date}`}>
                <Card className="group cursor-pointer hover:border-primary/40 transition-all duration-200 overflow-hidden bg-card/60 hover:bg-card hover:shadow-md border-border/60">
                  <div className="p-5 flex items-center justify-between">
                    <div className="space-y-3 flex-1 pr-6">
                      <div className="flex items-center gap-3">
                        <h3 className="font-medium text-foreground text-lg group-hover:text-primary transition-colors">
                          {formattedDate}
                        </h3>
                        {allCompleted && (
                          <div className="flex items-center text-xs font-medium text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded">
                            <CheckCircle2 size={12} className="mr-1" />
                            Perfect day
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4">
                        <Progress value={progress} className="h-1.5 flex-1 max-w-[200px] bg-secondary" />
                        <span className="text-sm text-muted-foreground font-medium">
                          {entry.completedCount} / {entry.totalCount} completed
                        </span>
                      </div>
                    </div>
                    
                    <div className="w-10 h-10 rounded-full bg-secondary/50 group-hover:bg-primary/10 flex items-center justify-center transition-colors">
                      <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
