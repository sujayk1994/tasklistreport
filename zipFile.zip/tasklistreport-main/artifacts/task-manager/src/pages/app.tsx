import { useState, useEffect, useCallback, useRef } from "react";
import {
  useGetTodayTasks,
  getGetTodayTasksQueryKey,
  useCreateTodayTasks,
  useAddTask,
  useToggleTask,
  useSubmitDayTasks,
  useResetTodayTasks,
  useDeleteTask,
  useUpdateTaskNote,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Loader2, Plus, Check, RotateCcw, Trash2, MessageSquare, Copy, Clock } from "lucide-react";

function localDateKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatTaskDateLabel(
  createdAt: string | null | undefined,
): { text: string; isPending: boolean } | null {
  if (!createdAt) return null;
  const created = new Date(createdAt);
  if (isNaN(created.getTime())) return null;

  const today = new Date();
  const formatted = created.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });

  if (localDateKey(created) === localDateKey(today)) {
    return { text: `Added ${formatted}`, isPending: false };
  }
  return { text: `Pending from ${formatted}`, isPending: true };
}

export default function AppView() {
  const queryClient = useQueryClient();
  const [rawText, setRawText] = useState("");
  const [addText, setAddText] = useState("");
  const [commentTaskId, setCommentTaskId] = useState<number | null>(null);
  const [comments, setComments] = useState<Record<number, string>>({});
  const savedNotesRef = useRef<Record<number, string>>({});

  const { data: taskList, isLoading } = useGetTodayTasks({
    query: { queryKey: getGetTodayTasksQueryKey() },
  });

  useEffect(() => {
    if (!taskList?.tasks) return;
    const loaded: Record<number, string> = {};
    for (const t of taskList.tasks) {
      loaded[t.id] = t.note;
    }
    setComments((prev) => {
      const merged = { ...loaded };
      for (const id of Object.keys(prev)) {
        const numId = Number(id);
        if (numId in loaded) merged[numId] = prev[numId];
      }
      return merged;
    });
    savedNotesRef.current = loaded;
  }, [taskList]);

  const createTasks = useCreateTodayTasks();
  const addTask = useAddTask();
  const toggleTask = useToggleTask();
  const submitDay = useSubmitDayTasks();
  const resetDay = useResetTodayTasks();
  const deleteTask = useDeleteTask();
  const updateNote = useUpdateTaskNote();

  const handleCreate = () => {
    if (!rawText.trim()) return;
    createTasks.mutate(
      { data: { rawText } },
      {
        onSuccess: (data) => {
          queryClient.setQueryData(getGetTodayTasksQueryKey(), data);
          setRawText("");
          toast.success("Checklist created");
        },
        onError: () => toast.error("Failed to create checklist"),
      }
    );
  };

  const handleAddTask = () => {
    if (!addText.trim()) return;
    addTask.mutate(
      { data: { rawText: addText } },
      {
        onSuccess: (data) => {
          queryClient.setQueryData(getGetTodayTasksQueryKey(), data);
          setAddText("");
          toast.success("Task added");
        },
        onError: () => toast.error("Failed to add task"),
      }
    );
  };

  const handleToggle = (taskId: number) => {
    if (taskList?.submitted) return;
    queryClient.setQueryData(getGetTodayTasksQueryKey(), (old: any) => {
      if (!old) return old;
      return {
        ...old,
        tasks: old.tasks.map((t: any) =>
          t.id === taskId ? { ...t, completed: !t.completed } : t
        ),
      };
    });
    toggleTask.mutate(
      { data: { taskId } },
      {
        onError: () => {
          queryClient.invalidateQueries({ queryKey: getGetTodayTasksQueryKey() });
          toast.error("Failed to update task");
        },
      }
    );
  };

  const handleDeleteTask = (taskId: number) => {
    if (taskList?.submitted) return;
    queryClient.setQueryData(getGetTodayTasksQueryKey(), (old: any) => {
      if (!old) return old;
      return { ...old, tasks: old.tasks.filter((t: any) => t.id !== taskId) };
    });
    deleteTask.mutate(
      { data: { taskId } },
      {
        onSuccess: () => toast.success("Task removed"),
        onError: () => {
          queryClient.invalidateQueries({ queryKey: getGetTodayTasksQueryKey() });
          toast.error("Failed to remove task");
        },
      }
    );
  };

  const handleNoteBlur = useCallback((taskId: number, note: string) => {
    if (note === savedNotesRef.current[taskId]) return;
    savedNotesRef.current[taskId] = note;
    updateNote.mutate(
      { data: { taskId, note } },
      {
        onSuccess: (updated) => {
          queryClient.setQueryData(getGetTodayTasksQueryKey(), (old: any) => {
            if (!old) return old;
            return {
              ...old,
              tasks: old.tasks.map((t: any) =>
                t.id === taskId ? { ...t, note: updated.note } : t
              ),
            };
          });
        },
        onError: () => toast.error("Failed to save note"),
      }
    );
  }, [updateNote, queryClient]);

  const handleCopyTask = async (text: string) => {
    await navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const handleSubmitDay = () => {
    submitDay.mutate(undefined, {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetTodayTasksQueryKey() });
        toast.success(data.message || "Day submitted successfully");
      },
      onError: () => toast.error("Failed to submit day"),
    });
  };

  const handleResetDay = () => {
    resetDay.mutate(undefined, {
      onSuccess: () => {
        queryClient.setQueryData(getGetTodayTasksQueryKey(), {
          id: 0,
          date: "",
          submitted: false,
          submittedAt: null,
          tasks: [],
        });
        setRawText("");
        setAddText("");
        toast.success("Day reset — ready to start fresh");
      },
      onError: () => toast.error("Failed to reset day"),
    });
  };

  if (isLoading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const hasTasks = taskList && taskList.tasks.length > 0;

  if (!hasTasks) {
    return (
      <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
        <div>
          <h1 className="text-3xl font-serif tracking-tight mb-2">Good morning.</h1>
          <p className="text-muted-foreground">What needs to get done today?</p>
        </div>
        <div className="space-y-4">
          <Textarea
            placeholder="Paste your tasks here, one per line..."
            className="min-h-[200px] text-base resize-none bg-card/50 shadow-sm border-border/60 focus-visible:ring-primary/20"
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleCreate();
            }}
          />
          <div className="flex justify-end">
            <Button
              onClick={handleCreate}
              disabled={!rawText.trim() || createTasks.isPending}
              className="gap-2"
            >
              {createTasks.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              Create Checklist
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const completedCount = taskList.tasks.filter((t) => t.completed).length;
  const totalCount = taskList.tasks.length;
  const allCompleted = completedCount === totalCount;
  const isSubmitted = taskList.submitted;

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      {/* Header */}
      <div className="flex items-end justify-between border-b border-border/50 pb-6">
        <div>
          <h1 className="text-3xl font-serif tracking-tight mb-2">Today's Focus</h1>
          <p className="text-muted-foreground text-sm font-medium">
            {completedCount} of {totalCount} tasks completed
          </p>
        </div>
        <div className="flex items-center gap-3">
          {isSubmitted && (
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-3 py-1.5 rounded-full">
              <Check size={14} />
              Day completed
            </div>
          )}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 text-muted-foreground hover:text-destructive"
                disabled={resetDay.isPending}
              >
                {resetDay.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <RotateCcw className="w-4 h-4" />
                )}
                Reset Day
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Reset today's tasks?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all of today's tasks and let you start over. This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleResetDay}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Yes, reset day
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Task list */}
      <div className="space-y-3">
        {taskList.tasks.map((task) => (
          <div key={task.id} className="space-y-2">
            <div
              className={`group flex items-start gap-4 p-4 rounded-lg border transition-all duration-200 ${
                task.completed
                  ? "bg-muted/30 border-transparent"
                  : "bg-card border-border/60 shadow-sm hover:border-primary/30 hover:shadow-md"
              } ${isSubmitted ? "opacity-80" : ""}`}
            >
              <Checkbox
                id={`task-${task.id}`}
                checked={task.completed}
                onCheckedChange={() => handleToggle(task.id)}
                disabled={isSubmitted}
                className="mt-1 w-5 h-5 rounded-sm transition-all flex-shrink-0"
              />

              {/* Task text — selectable */}
              <label
                htmlFor={`task-${task.id}`}
                className={`flex-1 cursor-pointer transition-all duration-200`}
                style={{ userSelect: "text" }}
              >
                <span
                  className={`block text-base leading-relaxed ${
                    task.completed ? "text-muted-foreground line-through" : "text-foreground"
                  }`}
                >
                  {task.text}
                </span>
                {(() => {
                  const label = formatTaskDateLabel(
                    (task as { createdAt?: string }).createdAt,
                  );
                  if (!label) return null;
                  return (
                    <span
                      className={`mt-1 inline-flex items-center gap-1 text-[11px] font-medium ${
                        label.isPending
                          ? "text-amber-600 dark:text-amber-500"
                          : "text-muted-foreground"
                      }`}
                    >
                      <Clock className="w-3 h-3" />
                      {label.text}
                    </span>
                  );
                })()}
              </label>

              {/* Action buttons */}
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className={`h-7 w-7 ${commentTaskId === task.id ? "text-primary" : "text-muted-foreground"}`}
                  onClick={() => setCommentTaskId(commentTaskId === task.id ? null : task.id)}
                  title="Add note"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground"
                  onClick={() => handleCopyTask(task.text)}
                  title="Copy task text"
                >
                  <Copy className="w-3.5 h-3.5" />
                </Button>
                {!isSubmitted && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={() => handleDeleteTask(task.id)}
                    title="Remove task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                )}
              </div>
            </div>

            {/* Inline note/comment */}
            {(commentTaskId === task.id || !!(comments[task.id] ?? task.note)) && (
              <div className="ml-9 animate-in fade-in slide-in-from-top-1 duration-200">
                <Textarea
                  placeholder="Add a note for this task..."
                  className="min-h-[80px] text-sm resize-none bg-muted/30 border-border/40 focus-visible:ring-primary/20"
                  value={comments[task.id] ?? ""}
                  onChange={(e) =>
                    setComments((prev) => ({ ...prev, [task.id]: e.target.value }))
                  }
                  onBlur={(e) => handleNoteBlur(task.id, e.target.value)}
                  readOnly={isSubmitted}
                />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add task section */}
      {!isSubmitted && (
        <div className="border-t border-border/50 pt-5 space-y-3">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Add more tasks
          </p>
          <Textarea
            placeholder="One task per line..."
            className="min-h-[90px] text-base resize-none bg-card/50 shadow-sm border-border/60 focus-visible:ring-primary/20"
            value={addText}
            onChange={(e) => setAddText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleAddTask();
            }}
          />
          <div className="flex justify-end">
            <Button
              onClick={handleAddTask}
              disabled={!addText.trim() || addTask.isPending}
              variant="secondary"
              className="gap-2"
            >
              {addTask.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              Add Task
            </Button>
          </div>
        </div>
      )}

      {/* Submit button */}
      {!isSubmitted && (
        <div className="pt-4 flex justify-end">
          <Button
            size="lg"
            variant={allCompleted ? "default" : "secondary"}
            onClick={handleSubmitDay}
            disabled={submitDay.isPending}
            className="w-full sm:w-auto px-8 shadow-sm"
          >
            {submitDay.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Check className="w-4 h-4 mr-2" />
            )}
            Submit Day
          </Button>
        </div>
      )}
    </div>
  );
}
