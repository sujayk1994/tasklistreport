import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { CheckSquare, Clock, Settings, LogOut, Shield } from "lucide-react";
import { useClerk } from "@clerk/react";
import { useIsAdmin } from "@/hooks/use-admin";
import { Button } from "@/components/ui/button";

export default function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { signOut } = useClerk();
  const isAdmin = useIsAdmin();

  const navItems = [
    { href: "/app", label: "Today", icon: CheckSquare },
    { href: "/history", label: "History", icon: Clock },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      <nav className="w-full md:w-64 border-b md:border-b-0 md:border-r border-border bg-card/50 p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-8 h-8 rounded-md bg-primary text-primary-foreground flex items-center justify-center">
            <CheckSquare size={18} />
          </div>
          <span className="font-serif font-semibold text-lg tracking-tight">Daily Tasks</span>
        </div>

        <div className="flex-1 flex flex-col gap-2">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/app" && location.startsWith(item.href));
            const Icon = item.icon;

            return (
              <Link key={item.href} href={item.href} className="block">
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start gap-3 h-10 ${isActive ? "font-medium" : "text-muted-foreground font-normal hover:text-foreground"}`}
                >
                  <Icon size={18} />
                  {item.label}
                </Button>
              </Link>
            );
          })}

          {isAdmin && (
            <Link href="/admin" className="block mt-2">
              <Button
                variant={location.startsWith("/admin") ? "secondary" : "ghost"}
                className={`w-full justify-start gap-3 h-10 ${location.startsWith("/admin") ? "font-medium" : "text-muted-foreground font-normal hover:text-foreground"}`}
              >
                <Shield size={18} />
                Admin
              </Button>
            </Link>
          )}
        </div>

        <div className="mt-auto pt-6">
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
            onClick={() => signOut()}
          >
            <LogOut size={18} />
            Sign out
          </Button>
        </div>
      </nav>

      <main className="flex-1 max-w-4xl mx-auto w-full p-6 md:p-12 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
