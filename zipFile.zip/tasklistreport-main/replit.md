# Daily Tasks — Task Manager App

## Overview

A personal daily task manager with login, daily checklists, email reporting, and task history.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Auth**: Clerk (`@clerk/express` on the API, `@clerk/react` on the SPA). In production, the API hosts a Clerk Frontend API proxy at `/api/__clerk` so auth works on custom domains without DNS changes.
- **Email**: Nodemailer (Gmail SMTP)
- **Frontend**: React + Vite, TailwindCSS, TanStack Query

## Features

- Login/signup via Clerk authentication
- Paste tasks (newline-separated) → auto-creates interactive checklist
- Check off completed tasks
- Submit at end of day → sends email report to configured recipients
- History view: browse past days' tasks date-by-date
- Settings: manage recipient email addresses
- **Carry-over**: incomplete tasks automatically appear in the next day's list until completed or deleted (created on first GET /tasks/today of the day, copied from the most recent prior list)
- **Email-driven task ingestion**: an IMAP poller reads `GMAIL_USER`'s inbox once a minute. Subjects matching `Twitter Marketing Reminder` or `Reprint Reminder` are parsed; every project line between `sent today:` and `Best Regards,` becomes a task on every existing user's today list, suffixed with ` - twitter marketing` or ` - Reprints`. Sub-bulleted lines (`  - X`) inherit the previous brand. Duplicate texts are skipped. See `artifacts/api-server/src/lib/inbox.ts`.
- Admin-only `POST /api/admin/inbox/simulate` endpoint accepts `{ subject, body }` and runs the same parser without IMAP — useful for testing.

## Environment Variables / Secrets Required

- `SESSION_SECRET` — Auto-provisioned for Replit Auth sessions
- `REPL_ID` / `REPLIT_DOMAINS` — Auto-provisioned by Replit Auth
- `GMAIL_USER` — Gmail address used to send task reports
- `GMAIL_APP_PASSWORD` — Gmail App Password (requires 2FA enabled)
- `DATABASE_URL` — Auto-provisioned by Replit PostgreSQL
- `SUPER_ADMIN_EMAIL` — Email of the user that gets the Admin panel

## Artifacts

- `artifacts/task-manager` — React + Vite frontend (preview at `/`)
- `artifacts/api-server` — Express API server (at `/api`)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Default Recipient Emails

Set via user Settings page, or pre-configured:
- vishnu@vellichormedia.com
- sujay@vellichormedia.com
